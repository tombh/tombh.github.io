<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="keywords go here" />
	
	<link rel="stylesheet" type="text/css" href="<?php echo $site_root; ?>styles.css" />
	<link rel="shortcut icon" type="image/ico" href="<?php echo $site_root; ?>favicon.ico" />
	
	<title><?php echo 'MY SITENAME -- ' . $pagetitle_for_browser ?></title>

</head>

<body>

	<h1 id="banner">^~. Your Amazing Templated Site .~^</h1>
	
	<div id="main_nav">
		<h2>
		Main Nav: <?php echo $main_nav_content; ?>
		<h2>
	</div>
	
	<div id="sub_nav">
		<h3>Sub Nav:
		<?php echo $sub_nav_content; ?>
		</h3>
	</div>
	
	<div id="content">
		<?php	if ( @!include($page_to_include) ) echo "This page doesn't exist!"; ?>
	</div><!--Content DIV ends here-->

	<div id="footer">
		<small>
		<p>All quotes courtesy of the <a href="http://www.canonical.org/~kragen/tao-of-programming.html">Tao of Programming</a></p>
		<p>This site was made using <a href="http://www.tombh.co.uk">Simplate 0.1</a></p>
		</small>
	</div>

</body>

</html>

