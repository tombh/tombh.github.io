<?php
//Simplate vesrion 0.1 by Thomas Buckley-Houston (www.tombh.co.uk)

//Please see the readme for usage instructions (and a funny joke!)

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~ SITE ARRAY ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
$site_root = '/Simplate-0.1';

/* "Directories" \/           \/ "Titles" \/              \/ "Filenames" \/                            */
//$directory_to_link_to      $pagetitle_for_HTML          $filename_to_link_to

//MAIN NAV HEADING ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
$site_array['/']       					['Section 1 Title'] 				= 'section1index.html'; //Front page for section
//MISC INFO ------------------------------------------------------------------------------
$site_array['/']['tab_id'] = 'section1_button'; //CSS ID
$site_array['/']['tip'] = 'Click this button to view Section 1'; //anchor title attribute
//SUB NAV HEADINGS ----------------------------------------------------------------	
$site_array['/']								['Section 1 - Sub-Page 1']	= 'subpage1.html'; //section page
$site_array['/'] 								['Section 1 - Sub-Page 2']	= 'subpage2.html'; //section page 
$site_array['/']								['Section 1 - Sub-Page 3'] 	= 'subpage3.html'; //section page
$site_array['/'] 								['Section 1 - Sub-Page 4'] 	= 'subpage4.html'; //section page
//---------------------------------------------------------------------------------


//MAIN NAV HEADING ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
$site_array['section2']  	 	 		['Section 2 Title'] 				= 'section2index.html';
//MISC INFO-------------------------------------------------------------------------
$site_array['section2']['tab_id'] = 'section2_button';
$site_array['section2']['tip'] = 'Click this button to view Section 2';
//SUB NAV HEADINGS ----------------------------------------------------------------
//no sub pages
//You can just have one page in a section if you want! :)
//no sub pages
//---------------------------------------------------------------------------------


//MAIN NAV HEADING ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
$site_array['section3'] 				['Section 3 Title'] 	   		= 'section3index.html';
//MISC INFO ------------------------------------------------------------------------
$site_array['section3']['tab_id'] = 'section3_button';
$site_array['section3']['tip'] = 'Click this button to view Section 3';
//SUB NAV HEADINGS -----------------------------------------------------------------
$site_array['section3'] 				['Section 3 - Sub-Page 1']  = 'subpage1.html'; 
$site_array['section3']					['Section 3 - Sub-Page 2']  = 'subpage2.html'; 
//----------------------------------------------------------------------------------

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~ END OF SITE ARRAY ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


//THE CODE   01000100100010101001001001001   THE CODE   010010010001111100101001001111010010010010   THE CODE

//First we need to find out which page is being viewed
$current_directory = $_GET['section'];
$current_page = $_GET['page'];

if ( empty($current_page) && empty($current_directory) ){
	$current_page = reset(reset($site_array));
	$current_directory = '/';
	}

$forward_slash = ($current_directory == '/') ? '' : '/';

$page_to_include = $current_directory.$forward_slash.$current_page;

//Between these two foreach() loops we go through the whole site-map
//$directory will thus point to the FIRST '[]' elements
//$contents will thus point to the SECOND '[]' elements
foreach($site_array as $directory_to_link_to => $contents){
	
	$loop_number = 0; //resets the foreach($contents) loop count

		///////////////////////////////////////////////////////////////////////////////////////////
		foreach($contents as $pagetitle_for_HTML => $filename_to_link_to){
		//Variables are self-explanatory
		
			if ($pagetitle_for_HTML == 'tab_id' || $pagetitle_for_HTML == 'tip') continue; //Don't want to make pages from the misc information

			$url = 'index.php?section='.$directory_to_link_to.'&page='.$filename_to_link_to; 

			//-------------------------------------------------------------------------------------
			//This fills the Main Nav by taking advantage of the fact that the mainnav title
			//is always found in the first row of the site-map's sections
			$loop_number++;
			if ($loop_number == 1){

				if ($directory_to_link_to == $current_directory){	

					$pre_tags= "\n\n" . '
			<span id="' . $site_array[$directory_to_link_to]['tab_id'] . '">
				<a href="' . $url . '" class="current" title="' . $site_array[$directory_to_link_to]['tip'] . '">';
				   	$post_tags='</a>
			</span>';

					$pagetitle_for_browser = $pagetitle_for_HTML;

				}else{

					$pre_tags= "\n\n" . '
			<span id="' . $site_array[$directory_to_link_to]['tab_id'] . '">
				<a href="' . $url . '" title="' . $site_array[$directory_to_link_to]['tip'] . '">';
				  $post_tags='</a>
			</span>';
				   	

				}
				
				$main_nav_content .= $pre_tags . $pagetitle_for_HTML . $post_tags;
								
			}
			//-----------------------------------------------------------------------------------------



			//-------------------------------------------------------------------------------------------
			//This fills the Sub Nav AND outputs the page title
			if ($loop_number != 1 && $directory_to_link_to == $current_directory){
								
				//This is what to do when viewing an ACTUAL PAGE from the site map
				if ($current_page == $filename_to_link_to){

					$pre_tags = "\n" . '<a class="current" href="' . $url . '">';
				  $post_tags = '</a>';

					$pagetitle_for_browser = $pagetitle_for_HTML;

				}else{

					$pre_tags = "\n" . '<a href="' . $url . '">';
					$post_tags = '</a>';

				}

				$sub_nav_content .= $pre_tags . $pagetitle_for_HTML . $post_tags;

			}
			//-------------------------------------------------------------------------------------------




		}// end of foreach()$contents loop
		///////////////////////////////////////////////////////////////////////////////////////////////////

}//end of foreach($site_array) loop

//this just gives an extra ID tag to help with CSS
$sub_nav_content = '<div id="sectionlinks">' . $sub_nav_content . '</div>'; 

/**Paths are always so fiddly!
* I always find the _SERVER variable, DOCUMENT_ROOT, to be inconsistent,
* sometimes it ends with a slash sometimes not.
*/
if ( substr($_SERVER['DOCUMENT_ROOT'], -1) == '/'){ //if the last character of the DOCUMENT ROOT is a forward slash
	$include_root = substr($_SERVER['DOCUMENT_ROOT'], 0, -1).$site_root.'/'; //strip that forward slash
}else{
	$include_root = $_SERVER['DOCUMENT_ROOT'].$site_root.'/'; //leave it alone
}

$page_to_include = $include_root.$page_to_include;

//This is for the HTML paths -- like for the CSS and favicon
$site_root .= '/' 

// 01001001001010010010100100100101001001000101010011111010010010011101111010010010001000100100100100100100100100101
?>

<?php include('template.php'); ?>
