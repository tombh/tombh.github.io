WHAT IS THIS?
Simplate is very simple templating system to make desgining and maintaining websites easier.

HOW DO I USE IT?
All you have to do to make a site with it is;
(1) put the structure of your site into the site array
(2) edit the template.php to produce the layout of your site
(3) edit the CSS file to style the design of your site
(4) put **just the content** of each webpage into its own file

To give you an idea of how this works, Simplate comes already setup with an example site
to help you get started. Just upload the contents of the Simplate directory to your server
amnd point your browser to the root (or index.php if that doesn't work).

THE SITE ARRAY
The Site Array can be found at the top of index.php. Firstly you must specify the site root,
this the path required to reach the index.php file, do not include a trailing slash.

Each row of the array represents a single page in the website (apart from the MISC INFO elements).
The Site Array has already been filled with the data for the example site so 
study it to see how it corresponds to the files of the example site.
.
It is assumed that the web pages for each SECTION of your site will be
contained within indivdual directories. Put the directory name into the first column
of the array as indicated.
 
The title of each site-section is taken from the FIRST row of each array-section, 
in the example below these are "Section 1 Title", "Section 2 Title", etc.

The title for each page itself is put into the second column of the array.

You can also specify the CSS ID name and title attribute for each *MAIN-NAV* link through 
the MISC INFO entries.

The actual file that contains the HTML (or even PHP) for that page is entered into the third and final 
column for each entry.

THE TEMPLATE
This file contains all the code that will suround the individual page contents, therefore it will
appear on every single page.

index.php provides 5 variables for use in the template file;
$site_root
$pagetitle_for_browser
$main_nav_content
$sub_nav_content
$page_to_include

THE CONTENT
Now all you have to do is fill each individual page of your site with content :)
Hooray!

THE FUNNY JOKE (as promised)
Q: What is the difference between roast beef and pea soup?
A: Well *anyone* can roast beef!
